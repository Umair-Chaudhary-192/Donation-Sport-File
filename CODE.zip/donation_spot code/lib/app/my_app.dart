import 'package:base_project/game/game.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:toast/toast.dart';
import '../utils/app_imports/app_imports.dart';

class MyApp extends StatefulWidget {
  MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  // For Firebase uncomment
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();
  var country = storageBox.read(StorageConstants.langCountry) ?? 'US'; // 'US'
  var lang = storageBox.read(StorageConstants.langCode) ?? 'en'; // 'French'

  @override
  void dispose() {
    // TODO: implement dispose
    WidgetsBinding.instance.removeObserver(this);

    super.dispose();
  }

  @override
  void initState() {
    // storageBox.erase();
    WidgetsBinding.instance.addObserver(this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    debugPrint('build- MyApp');
    ToastContext().init(context);
    return AppAnnotatedRegionWidget(
      child: GetMaterialApp(
        fallbackLocale: Locale(country.toString(), lang.toString()),
        useInheritedMediaQuery: false,
        debugShowCheckedModeBanner: false,
        // initialRoute: const SplashView(),
        // AppPages.initialRoute,
        title: 'Donation Spot',
        themeMode: ThemeMode.system,
        // getPages: AppPages.routes,
        theme: ThemeData.light(),
        home: SplashView(),
      ),
    );
  }
}

// - Keyboard hide by tapping
class AppAnnotatedRegionWidget extends StatelessWidget {
  const AppAnnotatedRegionWidget({
    super.key,
    required this.child,
  });

  final Widget child;

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle(
          systemNavigationBarColor: Colors.transparent,
          systemNavigationBarDividerColor: Colors.transparent,
          systemNavigationBarIconBrightness:
              Theme.of(context).brightness == Brightness.dark
                  ? Brightness.light
                  : Brightness.dark,
          systemNavigationBarContrastEnforced: true,
        ),
        child: child,
      ),
    );
  }
}
