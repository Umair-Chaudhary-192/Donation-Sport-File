import 'dart:io';

import 'package:base_project/utils/app_imports/app_imports.dart';
import 'package:firebase_storage/firebase_storage.dart';

class CreatePostController extends GetxController {
  var isLoading = false.obs;
  AuthController authController = Get.put(AuthController());
  TextEditingController organizationNameController = TextEditingController();
  TextEditingController organizationDiscriptionController =
      TextEditingController();
  TextEditingController organizationUrlController = TextEditingController();
  var picturePath = ''.obs;
  var downloadUrl = ''.obs;

  void setImage(String path) {
    debugPrint("path $path");
    picturePath.value = path;
    update();
  }

///////////////
  final _selectedValue = 0.obs;
  set setSelectedValue(value) => _selectedValue.value = value;
  get getSelectedValue => _selectedValue.value;

////////////
  var _chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
  Random _rnd = Random();

  String getRandomString(int length) => String.fromCharCodes(Iterable.generate(
      length, (_) => _chars.codeUnitAt(_rnd.nextInt(_chars.length))));

  /////////////////////////create user
  Future setOrganizations() async {
    // try {
    var random = getRandomString(15);

    if (organizationNameController.text == '' &&
        organizationDiscriptionController.text == '' &&
        organizationUrlController.text == '') {
      customSnackBar(title: 'All Fields are Required');
    }
    //  else if (authController.picturePath.value == '') {
    //   customSnackBar(title: 'Please add Image');
    // }
    else if (organizationNameController.text == '') {
      customSnackBar(title: 'Please write Organization Name');
    } else if (organizationDiscriptionController.text == '') {
      customSnackBar(title: 'Please write little bit about Organization');
    } else if (organizationUrlController.text == '') {
      customSnackBar(title: 'Url is Required');
    } else {
      isLoading(true);
      if (picturePath.value != '') {
        var snapshot = await FirebaseStorage.instance
            .ref()
            .child('uploads/Organization/$random.jpg')
            .putFile(File(picturePath.value));
        downloadUrl.value = await snapshot.ref.getDownloadURL();
      }
      await FirebaseFirestore.instance
          .collection('Organizations')
          .doc('admin')
          .collection('AllOrganizations')
          .doc(random)
          .set({
        'timestamp': DateTime.now().toString(),
        'name': organizationNameController.text,
        'discription': organizationDiscriptionController.text,
        'image': picturePath.value == '' ? '' : downloadUrl.value,
        'url': organizationUrlController.text,
        'id': random,
        'priority': getSelectedValue,
      }).then((value) {
        print('data set');
        isLoading(false);
        organizationNameController.text = '';
        organizationDiscriptionController.text = '';
        organizationUrlController.text = '';
        picturePath.value = '';
        isLoading(false);
      });
    }
    isLoading(false);
    // } catch (e) {
    //   // isLoading(false);
    // } finally {
    //   // isLoading(false);
    // }
  }
}
