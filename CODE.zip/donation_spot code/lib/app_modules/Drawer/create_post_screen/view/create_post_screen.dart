import 'dart:io';

import 'package:base_project/app_modules/Drawer/create_post_screen/controller/create_post_controller.dart';
import 'package:base_project/utils/app_imports/app_imports.dart';
import 'package:image_picker/image_picker.dart';

class CreatePostScreen extends StatefulWidget {
  const CreatePostScreen({super.key});

  @override
  State<CreatePostScreen> createState() => _CreatePostScreenState();
}

class _CreatePostScreenState extends State<CreatePostScreen> {
  AuthController authController = Get.put(AuthController());
  CreatePostController createPostController = Get.put(CreatePostController());
  ImagePicker imagePicker = ImagePicker();

  Future addImage() async {
    final pickImage = await imagePicker.pickImage(
        source: ImageSource.gallery, imageQuality: 100);
    if (pickImage == null) return;

    final pickedImage = File(pickImage.path);
    createPostController.setImage(pickedImage.path);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.BACKGROUND_COLOR,
      body: Column(
        children: [
          Padding(
            padding: AppPaddings.horizontal,
            child: PrimaryAppBar(
              isPrefix: true,
              isTitle: true,
              isBack: true,
              isHomeScreenTitle: false,
              userName: 'Add Organization',
              prefixTap: () {
                Get.back();
              },
            ),
          ),
          Expanded(
              child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                    onTap: () {
                      addImage();
                    },
                    child: Align(
                      alignment: Alignment.center,
                      child: Stack(
                        children: [
                          Obx(() {
                            return createPostController.picturePath.value == ""
                                ? CircleAvatar(
                                    radius: 55,
                                    backgroundColor:
                                        Colors.grey.withOpacity(.5),
                                    child: const CircleAvatar(
                                        radius: 40,
                                        backgroundColor: Colors.transparent,
                                        backgroundImage: AssetImage(
                                            'assets/images/png/Gallery.png')),
                                  )
                                : CircleAvatar(
                                    backgroundColor: AppColors.PRIMARY_COLOR
                                        .withOpacity(0.4),
                                    radius: 55,
                                    backgroundImage: FileImage(
                                      File(
                                        createPostController.picturePath.value,
                                      ),
                                    ),
                                  );
                          }),
                          Positioned(
                              bottom: 0,
                              right: 0,
                              child: CircleAvatar(
                                backgroundColor:
                                    AppColors.PRIMARY_COLOR.withOpacity(0.7),
                                radius: 15,
                                child: const Icon(
                                  Icons.add,
                                  color: Colors.white,
                                ),
                              ))
                        ],
                      ),
                    ),
                  ),
                  vSizedBox(),
                  AppText(
                    text: 'Organization Name',
                    color: AppColors.WHITE_COLOR,
                    fontWeight: FontWeight.w600,
                    size: AppDimensions.FONT_SIZE_18,
                  ),
                  vSizedBox(),
                  AppTextField(
                    controller: createPostController.organizationNameController,
                    borderRadius: AppDimensions.FONT_SIZE_05,
                    enabledBorderColor: AppColors.GRAY,
                    textColor: AppColors.WHITE_COLOR,
                    focusedBorderColor:
                        AppColors.PRIMARY_COLOR.withOpacity(0.6),
                  ),
                  vSizedBox(),
                  AppText(
                    text: 'About Organization',
                    color: AppColors.WHITE_COLOR,
                    fontWeight: FontWeight.w600,
                    size: AppDimensions.FONT_SIZE_18,
                  ),
                  vSizedBox(),
                  AppTextField(
                    controller:
                        createPostController.organizationDiscriptionController,
                    borderRadius: AppDimensions.FONT_SIZE_05,
                    enabledBorderColor: AppColors.GRAY,
                    textColor: AppColors.WHITE_COLOR,
                    focusedBorderColor:
                        AppColors.PRIMARY_COLOR.withOpacity(0.6),
                  ),
                  vSizedBox(),
                  AppText(
                    text: 'Organization url',
                    color: AppColors.WHITE_COLOR,
                    fontWeight: FontWeight.w600,
                    size: AppDimensions.FONT_SIZE_18,
                  ),
                  vSizedBox(),
                  AppTextField(
                    controller: createPostController.organizationUrlController,
                    borderRadius: AppDimensions.FONT_SIZE_05,
                    enabledBorderColor: AppColors.GRAY,
                    textColor: AppColors.WHITE_COLOR,
                    focusedBorderColor:
                        AppColors.PRIMARY_COLOR.withOpacity(0.6),
                  ),
                  vSizedBox(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Radio<int>(
                            value: 0,
                            activeColor: AppColors.PRIMARY_COLOR,
                            fillColor: MaterialStateProperty.all(Colors.white),
                            groupValue: createPostController.getSelectedValue,
                            onChanged: (value) {
                              setState(() {
                                createPostController.setSelectedValue = value;
                              });
                            },
                          ),
                          AppText(text: 'Famous', color: AppColors.WHITE_COLOR),
                        ],
                      ),
                      Row(
                        children: <Widget>[
                          Radio<int>(
                            value: 1,
                            activeColor: AppColors.PRIMARY_COLOR,
                            fillColor: MaterialStateProperty.all(Colors.white),
                            groupValue: createPostController.getSelectedValue,
                            onChanged: (value) {
                              setState(() {
                                createPostController.setSelectedValue = value;
                              });
                            },
                          ),
                          AppText(
                              text: 'Infamous', color: AppColors.WHITE_COLOR),
                        ],
                      ),
                    ],
                  ),
                  vSizedBox(height: 40),
                  Obx(
                    () => createPostController.isLoading.isTrue
                        ? customLoader(AppColors.PRIMARY_COLOR)
                        : AppButton(
                            buttonRadius: AppBorderRadius.BORDER_RADIUS_05,
                            buttonWidth: Get.width,
                            buttonName: 'Add',
                            buttonColor: AppColors.PRIMARY_COLOR,
                            textColor: AppColors.WHITE_COLOR,
                            onTap: () async {
                              await createPostController.setOrganizations();
                            },
                          ),
                  )
                ],
              ),
            ),
          ))
        ],
      ),
    );
  }
}
