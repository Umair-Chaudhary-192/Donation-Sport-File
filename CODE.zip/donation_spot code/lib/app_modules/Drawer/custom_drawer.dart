import 'package:base_project/app_modules/Drawer/create_post_screen/view/create_post_screen.dart';
import 'package:base_project/app_modules/Drawer/my_donation_screen/my_donation_screen.dart';

import '../../utils/app_imports/app_imports.dart';

class CustomDrawer extends StatelessWidget {
  AuthController authController = Get.put(AuthController());
  @override
  Widget build(BuildContext context) {
    return Drawer(
        backgroundColor: AppColors.BACKGROUND_COLOR,
        child: Padding(
          padding: AppPaddings.horizontal,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              vSizedBox(height: Get.height * 0.1),
              Image.asset(
                AppImages.logoPng,
                scale: 3,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 17.0),
                child: AppText(
                  text: storageBox
                      .read(StorageConstants.loggedInData)['user_name'],
                  size: AppDimensions.FONT_SIZE_24,
                  color: AppColors.PRIMARY_COLOR,
                  fontWeight: FontWeight.w600,
                ),
              ),
              vSizedBox(height: Get.height * 0.03),
              storageBox.read(StorageConstants.loggedInData)['user_email'] ==
                      'admin@gmail.com'
                  ? profileSceentitleWidget(
                      icons: '', //AppImages.profileUpdateIcon,
                      title: 'Add Organization',
                      onTap: () {
                        Get.to(const CreatePostScreen());
                      })
                  : const SizedBox.shrink(),

              profileSceentitleWidget(
                  icons: '', //AppImages.profileUpdateIcon,
                  title: 'My Donations',
                  onTap: () {
                    Get.to(const MyDonationScreen());
                    // Get.toNamed(Routes.myProfileScreen);
                  }),

              // vSizedBox(height: 10),
              profileSceentitleWidget(
                  icons: '', //AppImages.logoutIcon,
                  title: 'Logout',
                  onTap: () {
                    authController.signOut();
                    // Get.offAll(MainAuthScreen());
                  }),
            ],
          ),
        ));
  }

  profileSceentitleWidget({
    String? icons,
    String? title,
    VoidCallback? onTap,
  }) {
    return GestureDetector(
      onTap: onTap!,
      child: Container(
        padding: AppPaddings.defaultPadding,
        decoration: BoxDecoration(
          borderRadius: AppBorderRadius.BORDER_RADIUS_10,
        ),
        child: Row(
          children: [
            icons == '' ? const SizedBox.shrink() : SvgPicture.asset(icons!),
            icons == '' ? const SizedBox.shrink() : hSizedBox(),
            AppText(
                text: title!,
                color: AppColors.WHITE_COLOR,
                fontWeight: FontWeight.w500)
          ],
        ),
      ),
    );
  }
}
