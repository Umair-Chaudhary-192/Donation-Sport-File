import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:intl/intl.dart';

import '../../../utils/app_imports/app_imports.dart';

class MyDonationScreen extends StatefulWidget {
  const MyDonationScreen({super.key});

  @override
  State<MyDonationScreen> createState() => _MyDonationScreenState();
}

class _MyDonationScreenState extends State<MyDonationScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.BACKGROUND_COLOR,
      body: Column(
        children: [
          Padding(
            padding: AppPaddings.horizontal,
            child: PrimaryAppBar(
              isPrefix: true,
              isTitle: true,
              isBack: true,
              isHomeScreenTitle: false,
              userName: 'My Donations',
              prefixTap: () {
                Get.back();
              },
            ),
          ),
          Expanded(
            child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: SingleChildScrollView(
                  child: StreamBuilder(
                      stream: FirebaseFirestore.instance
                          .collection('Transaction')
                          .doc(FirebaseAuth.instance.currentUser!.uid)
                          .collection('AllTransaction')
                          .orderBy('timestamp', descending: true)
                          .snapshots(),
                      builder:
                          (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                        if (snapshot.hasError) {
                          return const Text('Something went wrong');
                        }
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return const Center(child: Text("Loading"));
                        }
                        return snapshot.data!.docs.isEmpty
                            ? Column(
                                children: [
                                  vSizedBox(height: 40),
                                  Image.asset("assets/images/png/notfound.png"),
                                  AppText(
                                      text:
                                          'You have not done any donation yet Please donate and help people in need',
                                      color: AppColors.WHITE_COLOR,
                                      size: AppDimensions.FONT_SIZE_20,
                                      textAlign: TextAlign.center)
                                ],
                              )
                            : ListView.builder(
                                physics: const BouncingScrollPhysics(),
                                itemCount: snapshot.data!.docs.length,
                                shrinkWrap: true,
                                itemBuilder: (context, index) {
                                  return Container(
                                    width: Get.width * 0.8,
                                    margin: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 10),
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                        color: AppColors.BLACK,
                                        boxShadow: [
                                          BoxShadow(
                                            color:
                                                AppColors.GRAY.withOpacity(0.2),
                                            offset: const Offset(0, 3),
                                            blurRadius: 3,
                                            spreadRadius: 0,
                                          ),
                                        ],
                                        borderRadius:
                                            AppBorderRadius.BORDER_RADIUS_05,
                                        border: Border.all(
                                            width: 1,
                                            color: AppColors.WHITE_COLOR
                                                .withOpacity(0.2))),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            AppText(
                                                text:
                                                    "Transcation Id: TID${snapshot.data!.docs[index]['id']}",
                                                color: AppColors.WHITE_COLOR,
                                                size:
                                                    AppDimensions.FONT_SIZE_12)
                                          ],
                                        ),
                                        vSizedBox(),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            SizedBox(
                                              width: Get.width * 0.5,
                                              child: AppText(
                                                  text:
                                                      snapshot.data!.docs[index]
                                                          ['organization'],
                                                  fontWeight: FontWeight.w600,
                                                  color: AppColors.WHITE_COLOR,
                                                  overflow:
                                                      TextOverflow.ellipsis),
                                            ),
                                            vSizedBox(),
                                            Row(
                                              children: [
                                                AppText(
                                                  text:
                                                      snapshot.data!.docs[index]
                                                          ['currency_type'],
                                                  fontWeight: FontWeight.w600,
                                                  color:
                                                      AppColors.PRIMARY_COLOR,
                                                ),
                                                hSizedBox(width: 05),
                                                AppText(
                                                  text: snapshot.data!
                                                      .docs[index]['amount']
                                                      .toString(),
                                                  fontWeight: FontWeight.w600,
                                                  color: AppColors.WHITE_COLOR,
                                                )
                                              ],
                                            ),
                                          ],
                                        ),
                                        vSizedBox(),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.end,
                                          children: [
                                            AppText(
                                                text:
                                                    "${DateFormat('h:mm a').format(DateTime.parse(snapshot.data!.docs[index]['timestamp']))} / ${DateFormat('dd-MM-yyyy').format(DateTime.parse(snapshot.data!.docs[index]['timestamp']))}",
                                                fontWeight: FontWeight.w600,
                                                color: AppColors.PRIMARY_COLOR,
                                                size:
                                                    AppDimensions.FONT_SIZE_14),
                                          ],
                                        )
                                      ],
                                    ),
                                  );
                                });
                      }),
                )),
          )
        ],
      ),
    );
  }
}
