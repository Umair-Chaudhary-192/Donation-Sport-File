import 'package:base_project/Utils/app_imports/app_imports.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/user.dart';

class AuthController extends GetxController {
  var isLoading = false.obs;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  TextEditingController emailController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController lastController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  TextEditingController donationPriceController = TextEditingController();

/////////
  final _selectedCurrency = 'USD'.obs;
  set setSelectedCurrency(value) => _selectedCurrency.value = value;
  get getSelectedCurrency => _selectedCurrency.value;
/////////showpassword
  final _showPassword = true.obs;
  set setShowPassword(value) => _showPassword.value = value;
  get getShowPassword => _showPassword.value;

/////////showConfirmpassword
  final _showConfirmPassword = true.obs;
  set setShowConfirmPassword(value) => _showConfirmPassword.value = value;
  get getShowConfirmPassword => _showConfirmPassword.value;

  final _showPass = false.obs;
  set setPassword(value) => _showPass.value = value;
  get getPassword => _showPass.value;

//////////signInWithEmailAndPassword
  Future<void> signInWithEmailAndPassword() async {
    try {
      isLoading(true);
      final String email = emailController.text.trim();
      final String password = passwordController.text.trim();

      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      getUserData();

      Get.offAll(() => const HomeScreen());
      isLoading(false);

      print('User signed in: ${userCredential.user}');
    } catch (e) {
      // Handle sign-in errors.
      customSnackBar(title: "${e}");
      isLoading(false);
      print('Failed to sign in: $e');
    }
  }

//////////////////Sign Up user with Email and password
  Future<bool> isEmailRegistered(String email) async {
    try {
      FirebaseAuth auth = FirebaseAuth.instance;

      List<String> signInMethods = await auth.fetchSignInMethodsForEmail(email);

      // If signInMethods is not empty, it means the email is already registered
      return signInMethods.isNotEmpty;
    } catch (e) {
      print('Failed to check email registration: $e');
      // Show an error message or handle the error
      return false;
    }
  }

  Future<void> signUp() async {
    String email = emailController.text.trim();
    String password = passwordController.text.trim();

    if (await isEmailRegistered(email)) {
      customSnackBar(title: 'Email is already registered!');
      // Show an error message or handle accordingly
    } else {
      try {
        await signUpWithEmailAndPassword(email, password);
        // Navigate to another screen or perform additional actions after successful sign-up
      } catch (e) {
        print('Failed to sign up: $e');
        // Show an error message or handle the error
      }
    }
  }

  Future<void> signUpWithEmailAndPassword(String email, String password) async {
    try {
      FirebaseAuth auth = FirebaseAuth.instance;

      UserCredential userCredential = await auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // User successfully signed up
      User? user = userCredential.user;
      setUserData(
        email: email,
        password: password,
        name: nameController.text,
      );
      print('Signed up: ${user!.uid}');

      // Perform additional actions after successful sign-up
    } catch (e) {
      print('Failed to sign up: $e');
      // Show an error message or handle the error
    }
  }

/////////////////////////create user
  Future setUserData({
    String? name,
    String? email,
    String? password,
  }) async {
    try {
      isLoading(true);
      // final prefs = await SharedPreferences.getInstance();
      print('Setting up user data');

      // String? token = await FirebaseMessaging.instance.getToken();

      //adding user detials
      await FirebaseFirestore.instance
          .collection('Users')
          .doc(FirebaseAuth.instance.currentUser!.uid)
          .set({
        'timestamp': DateTime.now().toString(),
        'user_name': name.toString(),
        'user_email': email.toString(),
        'password': password.toString(),
        'user_uid': FirebaseAuth.instance.currentUser!.uid,
      }).then((value) {
        // prefs.setString('uid', FirebaseAuth.instance.currentUser!.uid);
        // prefs.setBool('login', true);

        getUserData();
        Get.offAll(() => const HomeScreen());
        // Get.offAll(() => BottomNavigationScreen());
        isLoading(false);
      });
      isLoading(false);
    } catch (e) {
      // isLoading(false);
    } finally {
      // isLoading(false);
    }
  }

  /////////////////////////get UserData
  getUserData() async {
    try {
      isLoading(true);
      print('isLoading $isLoading');

      await FirebaseFirestore.instance
          .collection("Users")
          .doc(FirebaseAuth.instance.currentUser!.uid)
          .get()
          .then((value) {
        UserModel user = UserModel(
          // firstName: value.data()!["timestamp"],
          name: value.data()!["user_name"],
          email: value.data()!["user_email"],
          // phoneNumber: value.data()!["password"],
          password: value.data()!["password"],
          uid: value.data()!["user_uid"],
          timestamp: value.data()!["timestamp"],
        );
        storageBox.write(StorageConstants.loggedInData, value.data());
        print('data ${storageBox.read(StorageConstants.loggedInData)}');

        // Now, you can access user properties like this:

        // ...

        isLoading(false);
        update();
      });
    } catch (e) {
      print(e.toString());
      isLoading(false);
    }
  }

  Future<void> signOut() async {
    try {
      await _auth.signOut();
      // Clear the user data or perform any other necessary actions.
      // For example, you can clear the shared preferences.
      storageBox.erase();
      storageBox.remove(StorageConstants.loggedInData);

      Get.offAll(() => LoginScreen());
      // Navigate to the login screen or any other screen after logout.
    } catch (e) {
      // Handle sign-out errors, if any.
      print('Failed to sign out: $e');
    }
  }

  var _chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
  Random _rnd = Random();

  String getRandomString(int length) => String.fromCharCodes(Iterable.generate(
      length, (_) => _chars.codeUnitAt(_rnd.nextInt(_chars.length))));
/////////////////////////create user
  Future setDonation({
    String? paymentID,
    String? organization,
  }) async {
    // try {
    var random = getRandomString(15);

    isLoading(true);

    await FirebaseFirestore.instance
        .collection('Transaction')
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .collection('AllTransaction')
        .doc(random)
        .set({
      'organization': organization,
      'timestamp': DateTime.now().toString(),
      'amount': double.parse(authController.donationPriceController.text),
      'currency_type': getSelectedCurrency,
      'payment_id': paymentID,
      'id': random,
    }).then((value) {
      debugPrint('data set');
      isLoading(false);
      authController.donationPriceController.text = '';
      setSelectedCurrency = 'USD';
      isLoading(false);
      Get.back();
    });

    isLoading(false);
    // } catch (e) {
    //   // isLoading(false);
    // } finally {
    //   // isLoading(false);
    // }
  }
}
