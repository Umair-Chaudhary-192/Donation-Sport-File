import 'package:base_project/app_modules/authentication/widget/alreadyHaveandAccountWidget.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../../utils/app_imports/app_imports.dart';

class SignUpScreen extends StatefulWidget {
  SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  AuthController authController = Get.put(AuthController());
  // SocialAuthController socialAuthController = Get.put(SocialAuthController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.BACKGROUND_COLOR,
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Padding(
                padding: AppPaddings.horizontal,
                child: Column(
                  // crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    vSizedBox(height: Get.height * 0.08),
                    AppText(
                      text: "Registor",
                      fontWeight: FontWeight.w600,
                      size: AppDimensions.FONT_SIZE_30,
                      color: AppColors.WHITE_COLOR,
                      fontFamily: 'Merienda',
                    ),
                    AppText(
                      text: "Your Self",
                      fontWeight: FontWeight.w600,
                      size: AppDimensions.FONT_SIZE_20,
                      color: AppColors.WHITE_COLOR,
                      fontFamily: 'Merienda',
                    ),
                    vSizedBox(height: Get.height * 0.05),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                          width: Get.width * 0.9,
                          decoration: BoxDecoration(
                            color: AppColors.BLACK.withOpacity(0.8),
                            borderRadius: AppBorderRadius.BORDER_RADIUS_10,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(
                                    0.2), // Shadow color and opacity
                                spreadRadius: 5, // Spread radius
                                blurRadius: 10, // Blur radius
                                offset:
                                    const Offset(0, 3), // Offset from the top
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              AppText(
                                text: "Full Name",
                                fontWeight: FontWeight.w600,
                                size: AppDimensions.FONT_SIZE_18,
                                color: AppColors.WHITE_COLOR,
                                // fontFamily: 'Bariol',
                              ),
                              vSizedBox(height: AppDimensions.FONT_SIZE_10),
                              AppTextField(
                                controller: authController.nameController,
                                borderRadius: AppDimensions.FONT_SIZE_05,
                                enabledBorderColor: AppColors.GRAY,
                                textColor: AppColors.WHITE_COLOR,
                                focusedBorderColor:
                                    AppColors.PRIMARY_COLOR.withOpacity(0.6),
                              ),
                              vSizedBox(height: AppDimensions.FONT_SIZE_10),
                              AppText(
                                text: "Email Address",
                                fontWeight: FontWeight.w600,
                                size: AppDimensions.FONT_SIZE_18,
                                color: AppColors.WHITE_COLOR,
                                // fontFamily: 'Bariol',
                              ),
                              vSizedBox(height: AppDimensions.FONT_SIZE_10),
                              AppTextField(
                                controller: authController.emailController,
                                borderRadius: AppDimensions.FONT_SIZE_05,
                                enabledBorderColor: AppColors.GRAY,
                                textColor: AppColors.WHITE_COLOR,
                                focusedBorderColor:
                                    AppColors.PRIMARY_COLOR.withOpacity(0.6),
                              ),
                              vSizedBox(height: AppDimensions.FONT_SIZE_10),
                              AppText(
                                text: "Password",
                                fontWeight: FontWeight.w600,
                                size: AppDimensions.FONT_SIZE_18,
                                color: AppColors.WHITE_COLOR,
                              ),
                              vSizedBox(height: AppDimensions.FONT_SIZE_10),
                              Obx(() => AppTextField(
                                    controller:
                                        authController.passwordController,
                                    borderRadius: AppDimensions.FONT_SIZE_05,
                                    isSuffix: true,
                                    obscureText: authController.getShowPassword,
                                    enabledBorderColor: AppColors.GRAY,
                                    textColor: AppColors.WHITE_COLOR,
                                    focusedBorderColor: AppColors.PRIMARY_COLOR
                                        .withOpacity(0.6),
                                    suffixIcon: GestureDetector(
                                      onTap: () {
                                        authController.setShowPassword =
                                            authController.getShowPassword ==
                                                    false
                                                ? true
                                                : false;
                                      },
                                      child: Icon(
                                        authController.getShowPassword == false
                                            ? Icons.visibility_off
                                            : Icons.visibility,
                                        color: AppColors.PRIMARY_COLOR,
                                      ),
                                    ),
                                  )),
                              vSizedBox(height: AppDimensions.FONT_SIZE_10),
                              AppText(
                                text: "Confirm Password",
                                fontWeight: FontWeight.w600,
                                size: AppDimensions.FONT_SIZE_18,
                                color: AppColors.WHITE_COLOR,
                              ),
                              vSizedBox(height: AppDimensions.FONT_SIZE_10),
                              Obx(() => AppTextField(
                                    controller: authController
                                        .confirmPasswordController,
                                    borderRadius: AppDimensions.FONT_SIZE_05,
                                    isSuffix: true,
                                    obscureText:
                                        authController.getShowConfirmPassword,
                                    enabledBorderColor: AppColors.GRAY,
                                    textColor: AppColors.WHITE_COLOR,
                                    focusedBorderColor: AppColors.PRIMARY_COLOR
                                        .withOpacity(0.6),
                                    suffixIcon: GestureDetector(
                                      onTap: () {
                                        authController.setShowConfirmPassword =
                                            authController
                                                        .getShowConfirmPassword ==
                                                    false
                                                ? true
                                                : false;
                                        // if (authController
                                        //         .getShowConfirmPassword ==
                                        //     false) {
                                        //   authController
                                        //       .setShowConfirmPassword = true;
                                        // } else {
                                        //   authController
                                        //       .setShowConfirmPassword = false;
                                        // }
                                      },
                                      child: Icon(
                                        authController.getShowConfirmPassword ==
                                                false
                                            ? Icons.visibility_off
                                            : Icons.visibility,
                                        color: AppColors.PRIMARY_COLOR,
                                      ),
                                    ),
                                  )),
                              vSizedBox(height: Get.height * 0.05),
                              Obx(() => authController.isLoading.isTrue
                                  ? customLoader(AppColors.PRIMARY_COLOR)
                                  : AppButton(
                                      buttonWidth: Get.width,
                                      buttonName: "Sign Up",
                                      buttonColor: AppColors.PRIMARY_COLOR,
                                      textColor: AppColors.WHITE_COLOR,
                                      buttonRadius:
                                          AppBorderRadius.BORDER_RADIUS_05,
                                      onTap: () {
                                        if (authController
                                                    .emailController.text ==
                                                '' ||
                                            authController
                                                    .passwordController.text ==
                                                '' ||
                                            authController
                                                    .nameController.text ==
                                                '' ||
                                            authController
                                                    .confirmPasswordController
                                                    .text ==
                                                '') {
                                          customSnackBar(
                                              title: 'All Field Are Required');
                                        } else {
                                          if (!GetUtils.isEmail(authController
                                              .emailController.text)) {
                                            customSnackBar(
                                                title: 'Email is not valid');
                                          } else {
                                            if (authController
                                                    .passwordController.text !=
                                                authController
                                                    .confirmPasswordController
                                                    .text) {
                                              customSnackBar(
                                                  title:
                                                      'Password and Confirm Password Should be Same');
                                            } else {
                                              authController.signUp();
                                            }
                                          }
                                        }
                                      },
                                    )),
                              vSizedBox(height: Get.height * 0.05),
                              vSizedBox(),
                              alreadyHaveOrNotWidget(
                                text: "Already have an account?",
                                authText: 'Login'.tr,
                                onTap: () {
                                  Get.to(LoginScreen());
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
