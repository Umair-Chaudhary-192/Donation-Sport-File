import 'package:base_project/Utils/app_imports/app_imports.dart';

import '../../../utils/Fonts/AppDimensions.dart';

alreadyHaveOrNotWidget({
  String? text,
  String? authText,
  VoidCallback? onTap,
}) {
  return InkWell(
    onTap: onTap,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        AppText(
          text: text!,
          color: AppColors.WHITE_COLOR,
        ),
        hSizedBox(width: 05),
        AppText(
          text: authText!,
          color: AppColors.PRIMARY_COLOR,
          fontWeight: FontWeight.w600,
        ),
      ],
    ),
  );
}
