import 'package:base_project/utils/app_imports/app_imports.dart';

class Task {
  String date;
  String time;
  String services;
  String userId;
  String timestamp;

  Task({
    required this.date,
    required this.time,
    required this.services,
    required this.userId,
    required this.timestamp,
  });
}
