import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;

import '../../../utils/app_imports/app_imports.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

AuthController authController = Get.put(AuthController());

class _HomeScreenState extends State<HomeScreen> {
  // Default currency

  List<String> currencies = [
    'USD',
    'EUR',
    'GBP',
    'JPY',
    'AUD',
    'CAD',
    'CHF',
    'PKR',
    'INR'
  ];
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final List<String> images = [
    'assets/images/png/image11.png',
    'assets/images/png/image22.jpg',
    'assets/images/png/image33.jpg',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.BACKGROUND_COLOR,
      key: scaffoldKey,
      drawer: CustomDrawer(),
      body: SafeArea(
        top: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: AppPaddings.horizontal,
              child: PrimaryAppBar(
                isPrefix: true,
                isTitle: true,
                isHomeScreenTitle: false,
                userName: '',
                prefixTap: () {
                  scaffoldKey.currentState!.openDrawer();
                },
              ),
            ),
            CarouselSlider(
              items: images.map((image) {
                return Builder(
                  builder: (BuildContext context) {
                    return Container(
                      width: MediaQuery.of(context).size.width,
                      margin: const EdgeInsets.symmetric(horizontal: 5.0),
                      decoration: const BoxDecoration(
                        color: Colors.transparent,
                      ),
                      child: Image.asset(
                        image,
                        fit: BoxFit.contain,
                      ),
                    );
                  },
                );
              }).toList(),
              options: CarouselOptions(
                height: 200.0,
                autoPlay: true,
                autoPlayInterval: const Duration(seconds: 3),
                autoPlayAnimationDuration: const Duration(milliseconds: 800),
                autoPlayCurve: Curves.fastOutSlowIn,
                enlargeCenterPage: true,
              ),
            ),
            Expanded(
                child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    vSizedBox(),
                    AppText(
                        text: 'Recommended',
                        size: AppDimensions.FONT_SIZE_20,
                        color: AppColors.WHITE_COLOR),
                    vSizedBox(),
                    StreamBuilder(
                        stream: FirebaseFirestore.instance
                            .collection('Organizations')
                            .doc('admin')
                            .collection('AllOrganizations')
                            .orderBy('timestamp', descending: false)
                            .snapshots(),
                        builder:
                            (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (snapshot.hasError) {
                            return const Text('Something went wrong');
                          }
                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return const Center(child: Text("Loading"));
                          }
                          return Container(
                            width: Get.width * 0.9,
                            height: Get.height * 0.26,
                            margin: const EdgeInsets.symmetric(vertical: 10),
                            child: ListView.builder(
                                padding: EdgeInsets.zero,
                                physics: const BouncingScrollPhysics(),
                                scrollDirection: Axis.horizontal,
                                itemCount: snapshot.data!.docs.length,
                                itemBuilder: (context, index) {
                                  return organizationCard(
                                      data: snapshot.data!.docs[index]);
                                }),
                          );
                        }),
                    vSizedBox(),
                    AppText(
                        text: 'All Organizations',
                        size: AppDimensions.FONT_SIZE_20,
                        color: AppColors.WHITE_COLOR),
                    vSizedBox(),
                    StreamBuilder(
                        stream: FirebaseFirestore.instance
                            .collection('Organizations')
                            .doc('admin')
                            .collection('AllOrganizations')
                            .orderBy('timestamp', descending: true)
                            .snapshots(),
                        builder:
                            (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (snapshot.hasError) {
                            return const Text('Something went wrong');
                          }
                          if (snapshot.connectionState ==
                              ConnectionState.waiting) {
                            return const Center(child: Text("Loading"));
                          }
                          return ListView.builder(
                              padding: EdgeInsets.zero,
                              physics: const BouncingScrollPhysics(),
                              itemCount: snapshot.data!.docs.length,
                              shrinkWrap: true,
                              itemBuilder: (context, index) {
                                return organizationCard(
                                    data: snapshot.data!.docs[index]);
                              });
                        }),
                  ],
                ),
              ),
            )),
          ],
        ),
      ),
    );
  }

  organizationCard({var data}) {
    return Container(
      width: Get.width * 0.8,
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
          color: AppColors.BLACK,
          boxShadow: [
            BoxShadow(
              color: AppColors.GRAY.withOpacity(0.2),
              offset: const Offset(0, 3),
              blurRadius: 3,
              spreadRadius: 0,
            ),
          ],
          borderRadius: AppBorderRadius.BORDER_RADIUS_05,
          border: Border.all(
              width: 1, color: AppColors.WHITE_COLOR.withOpacity(0.2))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(
          children: [
            CircleAvatar(
              radius: 25,
              backgroundColor: AppColors.WHITE_COLOR.withOpacity(0.4),
              backgroundImage: NetworkImage(data['image']),
            ),
            hSizedBox(),
            SizedBox(
              width: Get.width * 0.55,
              child: AppText(
                text: data['name'],
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                size: AppDimensions.FONT_SIZE_20,
                color: AppColors.WHITE_COLOR,
              ),
            )
          ],
        ),
        vSizedBox(),
        SizedBox(
            width: Get.width * 0.8,
            child: AppText(
              text: data['discription'],
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              color: AppColors.WHITE_COLOR,
            )),
        vSizedBox(),
        Row(
          children: [
            Expanded(
                child: AppButton(
                    buttonRadius: AppBorderRadius.BORDER_RADIUS_05,
                    buttonName: "Donate",
                    buttonColor: AppColors.PRIMARY_COLOR,
                    textColor: AppColors.WHITE_COLOR,
                    onTap: () {
                      Get.bottomSheet(
                        Container(
                          padding: const EdgeInsets.only(
                              top: 10, left: 16, right: 16),
                          decoration: BoxDecoration(
                            color: AppColors.BLACK,
                            borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(
                                  10.0), // Top-left corner radius
                              topRight: Radius.circular(
                                  10.0), // Top-right corner radius
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                height: Get.height * 0.2,
                                decoration: BoxDecoration(
                                  color: AppColors.WHITE_COLOR,
                                  image: DecorationImage(
                                      image: NetworkImage(data['image'])),
                                  borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(
                                        10.0), // Top-left corner radius
                                    topRight: Radius.circular(
                                        10.0), // Top-right corner radius
                                  ),
                                ),
                              ),
                              // Row(
                              //   mainAxisAlignment: MainAxisAlignment.center,
                              //   children: [
                              //     vSizedBox(),
                              //     AppText(
                              //         text: 'Donate For a Good Cuse',
                              //         size: AppDimensions.FONT_SIZE_20,
                              //         color: AppColors.WHITE_COLOR),
                              //   ],
                              // ),
                              vSizedBox(),
                              AppText(
                                text: 'About Organization',
                                size: AppDimensions.FONT_SIZE_20,
                                color: AppColors.PRIMARY_COLOR,
                                fontWeight: FontWeight.w600,
                              ),
                              vSizedBox(),
                              SizedBox(
                                  width: Get.width * 0.87,
                                  child: AppText(
                                      text: data['discription'],
                                      color: AppColors.WHITE_COLOR)),
                              vSizedBox(),
                              AppText(
                                text:
                                    'Please Currency and enter amount you want to Donate',
                                size: AppDimensions.FONT_SIZE_20,
                                color: AppColors.PRIMARY_COLOR,
                                fontWeight: FontWeight.w600,
                              ),
                              vSizedBox(),
                              Row(
                                children: [
                                  Expanded(
                                      child: Obx(
                                    () => Container(
                                      padding: const EdgeInsets.only(left: 10),
                                      decoration: BoxDecoration(
                                        borderRadius: const BorderRadius.all(
                                            Radius.circular(05.0)),
                                        border: Border.all(
                                          color: AppColors.GRAY, // Border color
                                          width: 1, // Border width
                                        ),
                                      ),
                                      child: DropdownButton<String>(
                                        dropdownColor:
                                            AppColors.BACKGROUND_COLOR,
                                        value:
                                            authController.getSelectedCurrency,
                                        onChanged: (String? newValue) {
                                          setState(() {
                                            authController.setSelectedCurrency =
                                                newValue!;
                                          });
                                        },
                                        items:
                                            currencies.map((String currency) {
                                          return DropdownMenuItem<String>(
                                            value: currency,
                                            child: AppText(
                                                text: currency,
                                                color: AppColors.WHITE_COLOR),
                                          );
                                        }).toList(),
                                        icon: Padding(
                                          padding:
                                              const EdgeInsets.only(left: 80),
                                          child: Icon(Icons.arrow_drop_down,
                                              color: AppColors.WHITE_COLOR),
                                        ),
                                        underline: Container(),
                                      ),
                                    ),
                                  )),
                                  hSizedBox(),
                                  Expanded(
                                    child: AppTextField(
                                        controller: authController
                                            .donationPriceController,
                                        borderRadius: 05,
                                        enabledBorderColor: AppColors.GRAY,
                                        textColor: AppColors.WHITE_COLOR,
                                        keyboardType: TextInputType.number,
                                        focusedBorderColor:
                                            AppColors.PRIMARY_COLOR),
                                  )
                                ],
                              ),
                              vSizedBox(),
                              AppButton(
                                  buttonRadius:
                                      AppBorderRadius.BORDER_RADIUS_05,
                                  buttonName: "Donate",
                                  buttonWidth: Get.width,
                                  buttonColor: AppColors.PRIMARY_COLOR,
                                  textColor: AppColors.WHITE_COLOR,
                                  onTap: () {
                                    _makePayment(context, data['name']);
                                    Get.back();
                                  }),
                              vSizedBox(),
                              AppButton(
                                  buttonRadius:
                                      AppBorderRadius.BORDER_RADIUS_05,
                                  buttonName: "Cancel",
                                  buttonWidth: Get.width,
                                  buttonColor: AppColors.PRIMARY_COLOR,
                                  textColor: AppColors.WHITE_COLOR,
                                  onTap: () {
                                    // _makePayment(context);
                                    Get.back();
                                  }),
                              vSizedBox(height: 40),
                            ],
                          ),
                        ),
                        isScrollControlled: true,
                      );
                    })),
            hSizedBox(width: 10),
            Expanded(
                child: AppButton(
                    buttonRadius: AppBorderRadius.BORDER_RADIUS_05,
                    buttonName: "More",
                    buttonColor: AppColors.PRIMARY_COLOR,
                    textColor: AppColors.WHITE_COLOR,
                    onTap: () {
                      _launchWebsite(url: data['url']);
                    }))
          ],
        )
      ]),
    );
  }

  _launchWebsite({required String url}) async {
    final Uri _url = Uri.parse(url);
    // ignore: deprecated_member_use
    if (!await launchUrl(_url)) {
      throw Exception('Could not launch $_url');
    }
  }

/////////////////////////Stripe
  Map<String, dynamic>? paymentIntentData;

  Future<void> _makePayment(BuildContext context, String organization) async {
    try {
      // providerDetailListController.isLoading(true);
      double totalAmount =
          double.parse(authController.donationPriceController.text);

      ///providerDetailListController.total.value;
      debugPrint('totalAmount: $totalAmount');
      totalAmount = totalAmount;
      String currency = authController.getSelectedCurrency;
      paymentIntentData = await createPaymentIntent(
        '$totalAmount',
        currency,
      );
      if (paymentIntentData != null) {
        await Stripe.instance.initPaymentSheet(
            paymentSheetParameters: SetupPaymentSheetParameters(
          // applePay: true,
          // googlePay: true,
          // testEnv: true,
          // merchantCountryCode: 'US',
          merchantDisplayName: 'Prospects',
          customerId: paymentIntentData!['customer'],
          paymentIntentClientSecret: paymentIntentData!['client_secret'],
          customerEphemeralKeySecret: paymentIntentData!['ephemeralKey'],
        ));

        debugPrint("payment::: ${paymentIntentData}");
        // ignore: use_build_context_synchronously
        displayPaymentSheet(context, paymentIntentData!['id'], organization);
      }
    } catch (e, s) {
      debugPrint('exception:$e$s');
      // providerDetailListController.isLoading(false);
    }
  }

  displayPaymentSheet(
      BuildContext context, String paymentId, String organization) async {
    debugPrint('---- displayPaymentSheet -----');
    // providerDetailListController.isLoading(false);
    // return;
    try {
      await Stripe.instance.presentPaymentSheet();
      // RegistrationController().registerSellerApiRequest(context);

      Get.snackbar('Payment', 'Payment Successful',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: AppColors.PRIMARY_COLOR,
          colorText: Colors.white,
          margin: const EdgeInsets.all(10),
          duration: const Duration(seconds: 2));
      ///////////////////donation function here after
      authController.setDonation(
          paymentID: paymentId, organization: organization);
    } on Exception catch (e) {
      if (e is StripeException) {
        // providerDetailListController.isLoading(false);
        debugPrint("Error from Stripe: ${e.error.localizedMessage}");
      } else {
        // providerDetailListController.isLoading(false);
        debugPrint("Unforeseen error: ${e}");
      }
    } catch (e) {
      // providerDetailListController.isLoading(false);

      debugPrint("exception:$e");
    }
  }

  //  Future<Map<String, dynamic>>
  createPaymentIntent(String amount, String currency) async {
    try {
      Map<String, dynamic> body = {
        'amount': calculateAmount(amount),
        'currency': currency,
        'payment_method_types[]': 'card',
        // 'payment_method_options': 'fr-BE',
      };
      var response = await http.post(
          Uri.parse('https://api.stripe.com/v1/payment_intents'),
          body: body,
          headers: {
            'Authorization':
                'Bearer sk_test_QBKHRBdegd6aqvyULJJMYklh00mMGXBsqG',
            // 'Bearer sk_test_51LdrYoHsjvvnWgGs8xf52YoPgrDQ9wATdfFPuvMTcD0IgA4lxCAoSDKHslPrveTqZh6JKnn0QMfyl0eiH3h89ukP00lA0v7s3Q',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-localization': 'locale'.tr,
          });
      debugPrint(response.body);
      var jsonData = jsonDecode(response.body);
      // providerDetailListController.setPaymentIntent=jsonData['id'];
      return jsonDecode(response.body);
    } catch (err) {
      // providerDetailListController.isLoading(false);

      debugPrint('err charging user: ${err.toString()}');
    }
  }

  calculateAmount(String amount) {
    int a = (double.parse(amount) * 100).toInt();
    debugPrint('order price: $a');
    return a.toString();
  }
}
