import '../../../utils/app_imports/app_imports.dart';
import '../../authentication/models/user.dart';

class SplashView extends StatefulWidget {
  const SplashView({Key? key}) : super(key: key);

  @override
  State<SplashView> createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView>
    with SingleTickerProviderStateMixin {
  AnimationController? _controller;
  Animation<double>? _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 1.0, end: 1.2).animate(_controller!);

    Future.delayed(const Duration(seconds: 8), () async {
      var loggedInData = storageBox.read(StorageConstants.loggedInData) ?? '';
      if (loggedInData != '') {
        var data = jsonDecode(jsonEncode(loggedInData));
        UserModel user = UserModel(
          name: data["user_name"],
          email: data["user_email"],
          password: data["password"],
          uid: data["user_uid"],
          timestamp: data["timestamp"],
        );
        UserData.instance.userData = user;
      }
      debugPrint('loggedInData ; ${loggedInData.toString()}');
      if (loggedInData == null || loggedInData == '') {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (context) {
              // Replace `NextScreen` with the actual widget of your next screen
              return LoginScreen();
              // return HomeScreen();
            },
          ),
        );
      } else {
        Get.off(() => const HomeScreen());
      }
    });
  }

  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.BACKGROUND_COLOR,
      body: Column(
        children: [
          vSizedBox(height: Get.height * 0.15),
          Center(
            child: AnimatedBuilder(
              animation: _controller!,
              builder: (context, child) {
                return Transform.scale(
                  scale: _scaleAnimation!.value,
                  child: Image.asset(
                    AppImages.logoPng,
                  ),
                );
              },
            ),
          ),
          // vSizedBox(),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AppText(
                  text: 'Donation Spot',
                  color: AppColors.WHITE_COLOR,
                  fontWeight: FontWeight.w600,
                  size: AppDimensions.FONT_SIZE_30)
            ],
          )
        ],
      ),
    );
  }
}
