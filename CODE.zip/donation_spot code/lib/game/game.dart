import 'dart:async';

import 'package:base_project/game/model.dart';
import 'package:flutter/material.dart';

import 'package:flutter/material.dart';

class GameScreen extends StatefulWidget {
  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  final GameModel _gameModel = GameModel();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: () {
          if (!_gameModel.isGameStarted) {
            _gameModel.startGame();
          } else {
            // Make T-Rex jump
          }
        },
        child: Stack(
          children: const [
            Character(),
            Obstacle(
              width: 50,
              height: 50,
              imagePath: 'assets/images/png/hurdle.jpg',
            ),
            // You can add more elements here like the ground, score, etc.
          ],
        ),
      ),
    );
  }
}

class Ground extends StatelessWidget {
  final double width;
  final double height;

  const Ground({super.key, required this.width, required this.height});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      color: Colors.brown, // Or use an image that repeats
    );
  }
}

class Obstacle extends StatelessWidget {
  final double width;
  final double height;
  final String imagePath;

  const Obstacle(
      {super.key,
      required this.width,
      required this.height,
      required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: Image.asset(imagePath), // Add your obstacle images to assets
    );
  }
}

class Character extends StatelessWidget {
  const Character({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 100,
      width: 100,
      child: Image.asset(
          'assets/images/png/item.jpg'), // Add your T-Rex image to assets
    );
  }
}
