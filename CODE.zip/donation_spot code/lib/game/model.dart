import 'dart:async';

class GameModel {
  bool isGameStarted = false;
  late Timer _timer;

  void startGame() {
    isGameStarted = true;
    _timer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
      // Update game state
      // Move ground and obstacles
      // Check for collisions
    });
  }

  void endGame() {
    isGameStarted = false;
    _timer.cancel();
  }
}
