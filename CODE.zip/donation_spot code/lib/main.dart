import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:get_storage/get_storage.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'App/my_app.dart';
import 'utils/app_imports/app_imports.dart';

final storageBox = GetStorage();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  var directory = await getApplicationDocumentsDirectory();

  await Firebase.initializeApp();
  await GetStorage.init();
  Stripe.publishableKey = 'pk_test_PDKm8iAPqIq3mLuhQpm0vwAF00DvLrxre7';

  runApp(MyApp());
}
