// ignore_for_file: non_constant_identifier_names

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../Fonts/AppFonts.dart';

class AppColors {
  static Color PRIMARY_COLOR = const Color(0xFF80006A);
  static Color LIGHT_GREY_COLOR = const Color(0xFFEFEFF7);
  static Color BACKGROUND_COLOR = const Color(0xFF1A1A1A);
  static Color BLACK = const Color(0xff000000);
  static Color GRAY = const Color(0xff959595);
  static Color TRANSPARENT_COLOR = Colors.transparent;
  static Color RED_COLOR = const Color(0xFFDC2E45);
  static Color WHITE_COLOR = const Color(0xffFFFFFF);
  static Color TEXT_COLOR_COLOR = const Color(0xff4B4848);
  static Color OnGoing_Text_Color = const Color(0xffFFCF26);
  static Color Upcoming_Text_Color = const Color(0xff4DC3B5);
}

class GetTheme extends GetxController {
  var isDark = true.obs;

  updateMode() {
    isDark.value = true;
    ThemeHelper().switchTheme();
    isDark.value = false;
    update();
  }
}

class ThemeHelper {
  final _box = GetStorage();

  ThemeMode get theme => _loadThemeFromBox() ? ThemeMode.dark : ThemeMode.light;

  bool _loadThemeFromBox() => _box.read('') ?? false;

  _saveThemeToBox(bool isDarkMode) => _box.write('', isDarkMode);

  void switchTheme() {
    Get.changeThemeMode(_loadThemeFromBox() ? ThemeMode.light : ThemeMode.dark);

    _saveThemeToBox(!_loadThemeFromBox());
  }
}

class AppTheme {
  static ThemeData lightTheme = ThemeData(
    scaffoldBackgroundColor: AppColors.PRIMARY_COLOR,
    primaryColor: AppColors.PRIMARY_COLOR,
    primarySwatch: Colors.teal,
    brightness: Brightness.light,
    cardColor: AppColors.WHITE_COLOR,
    textTheme: TTextTheme.lightTextTheme,
    appBarTheme: const AppBarTheme(),
    floatingActionButtonTheme: FloatingActionButtonThemeData(),
    elevatedButtonTheme:
        ElevatedButtonThemeData(style: ElevatedButton.styleFrom()),
  );
  static ThemeData darkTheme = ThemeData(
    scaffoldBackgroundColor: AppColors.PRIMARY_COLOR,
    primaryColor: AppColors.PRIMARY_COLOR,
    primarySwatch: Colors.teal,
    brightness: Brightness.dark,
    textTheme: TTextTheme.darkTextTheme,
    appBarTheme: const AppBarTheme(),
    cardColor: const Color(0xff2f3e46),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(),
    elevatedButtonTheme:
        ElevatedButtonThemeData(style: ElevatedButton.styleFrom()),
  );
}

class TTextTheme {
  static TextTheme lightTextTheme = TextTheme(
    headline1: TextStyle(
        color: AppColors.BLACK,
        fontSize: 24,
        fontFamily: Weights.londrinaRegular),
    headline2: TextStyle(
        color: AppColors.BLACK,
        fontSize: 22,
        fontFamily: Weights.londrinaRegular),
    headline3: TextStyle(
        color: AppColors.BLACK,
        fontSize: 20,
        fontFamily: Weights.londrinaRegular),
    headline4: TextStyle(
        color: AppColors.BLACK,
        fontSize: 18,
        fontFamily: Weights.londrinaLight),
    headline5: TextStyle(
        color: AppColors.BLACK,
        fontSize: 16,
        fontFamily: Weights.londrinaLight),
    headline6: TextStyle(
        color: AppColors.BLACK,
        fontSize: 10,
        fontFamily: Weights.londrinaLight),

    //subtitle2: GoogleFonts.poppins(color: Colors.deepPurple, fontSize: 24),
  );
  static TextTheme darkTextTheme = TextTheme(
    headline1: TextStyle(
        color: AppColors.WHITE_COLOR,
        fontSize: 24,
        fontFamily: Weights.londrinaRegular),
    headline2: TextStyle(
        color: AppColors.WHITE_COLOR,
        fontSize: 22,
        fontFamily: Weights.londrinaRegular),
    headline3: TextStyle(
        color: AppColors.WHITE_COLOR,
        fontSize: 20,
        fontFamily: Weights.londrinaRegular),
    headline4: TextStyle(
        color: AppColors.WHITE_COLOR,
        fontSize: 18,
        fontFamily: Weights.londrinaLight),
    headline5: TextStyle(
        color: AppColors.WHITE_COLOR,
        fontSize: 16,
        fontFamily: Weights.londrinaLight),
    headline6: TextStyle(
        color: AppColors.WHITE_COLOR,
        fontSize: 10,
        fontFamily: Weights.londrinaLight),
  );
}
