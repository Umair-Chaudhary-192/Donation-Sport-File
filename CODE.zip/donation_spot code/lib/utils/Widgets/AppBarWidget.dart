import 'package:base_project/utils/app_imports/app_imports.dart';
import 'package:flutter_svg/svg.dart';

class PrimaryAppBar extends StatelessWidget {
  Color appbarColor;
  bool isPrefix;
  String title;
  String userName;
  VoidCallback? prefixTap;
  bool isSurffix;
  bool isCenter;
  bool isBack;
  bool isTitle;
  bool isHomeScreenTitle;
  bool isLogo;
  bool isSkip;

  VoidCallback? surffixTap;
  VoidCallback? menuTap;
  PrimaryAppBar({
    this.appbarColor = Colors.transparent,
    this.isBack = false,
    this.isSkip = false,
    this.isPrefix = false,
    this.isHomeScreenTitle = false,
    this.isSurffix = false,
    this.isCenter = false,
    this.isLogo = true,
    this.isTitle = true,
    this.title = '',
    this.userName = '',
    this.prefixTap,
    this.menuTap,
    this.surffixTap,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    // HomeController homeController = Get.put(HomeController());

    return Container(
      color: appbarColor,
      height:isHomeScreenTitle? Get.height / 7.12: Get.height / 8.12,
      width: Get.width,
      child: Stack(
        children: [
          // Obx(() =>
          isCenter
              ? Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  top: 28,
                  child: isLogo
                      ? Image.asset(
                          AppImages.logoPng,
                          scale: 8,
                        )
                      : const SizedBox.shrink(),
                )
              : const SizedBox.shrink(),
          // ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              vSizedBox(height: Get.height * 0.05),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    children: [
                      isPrefix
                          ? GestureDetector(
                              onTap: prefixTap,
                              child: Container(
                                height: Get.height * 0.05,
                                width: Get.height * 0.05,
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: AppColors.PRIMARY_COLOR,
                                  borderRadius:
                                      AppBorderRadius.BORDER_RADIUS_100,
                                ),
                                child: SvgPicture.asset(isBack
                                    ? AppImages.arrowBack
                                    : AppImages.menuIcon),
                              ),
                            )
                          : Container(),
                      isTitle ? hSizedBox(width: 10) : const SizedBox.shrink(),
                      isTitle
                          ? isHomeScreenTitle
                              ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    AppText(
                                      text: 'hello'.tr,
                                      fontWeight: FontWeight.w600,
                                      size: AppDimensions.FONT_SIZE_16,
                                      color: AppColors.TEXT_COLOR_COLOR,
                                    ),
                                    // vSizedBox(height: 05),
                                    AppText(
                                      text: userName,
                                      fontWeight: FontWeight.w500,
                                      size: AppDimensions.FONT_SIZE_16,
                                      color: AppColors.TEXT_COLOR_COLOR,
                                    )
                                  ],
                                )
                              : AppText(
                                  text: title,
                                  fontWeight: FontWeight.w600,
                                  size: AppDimensions.FONT_SIZE_18,
                                  color: AppColors.TEXT_COLOR_COLOR,
                                )
                          : const SizedBox.shrink(),
                    ],
                  ),
                  isSurffix
                      ? InkWell(
                          onTap: surffixTap,
                          child: Container(
                            height: Get.height * 0.06,
                            // width: Get.height * 0.0,
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: AppColors.TRANSPARENT_COLOR,
                              borderRadius: AppBorderRadius.BORDER_RADIUS_05,
                            ),
                            child: isSkip
                                ? AppText(
                                    text: "Skip",
                                    color: AppColors.PRIMARY_COLOR,
                                    fontWeight: FontWeight.w500)
                                : SvgPicture.asset(AppImages.cautionIcon),
                          ),
                        )
                      : Container(),
                ],
              )
            ],
          ),
        ],
      ),
    );
  }
}
