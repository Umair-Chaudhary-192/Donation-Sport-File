// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
// import '../Constants/app_images.dart';
// import '../Themes/AppColors.dart';
//
// Widget backGroundImage({
//   required Widget child,
//   Color? color,
//   double? opacity,
// }) {
//   return Container(
//       height: Get.height,
//       width: Get.width,
//       decoration: BoxDecoration(
//           color: color ?? AppColors.PRIMARY_COLOR,
//           image: DecorationImage(
//               image: AssetImage(AppImages.transparent),
//               fit: BoxFit.cover,
//               opacity: opacity ?? 0.4)),
//       child: child);
// }
