import '../app_imports/app_imports.dart';

customLine({
  double width = 80,
  double height = 07,
}) {
  return Container(
    width: 80,
    height: 07,
    decoration: BoxDecoration(
        color: AppColors.PRIMARY_COLOR,
        borderRadius: AppBorderRadius.BORDER_RADIUS_100),
  );
}
