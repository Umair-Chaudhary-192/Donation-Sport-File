import '../app_imports/app_imports.dart';

emptyState({
  String image='',
  String title='',
}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.center,
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      vSizedBox(height: 50),
      Image.asset(image),
      vSizedBox(),
      Container(
          width: Get.width * 0.8,
          child: AppText(
              text: title,//'noCustomerAvailable'.tr,
              color: AppColors.TEXT_COLOR_COLOR,
              textAlign: TextAlign.center))
    ],
  );
}