// ignore_for_file: constant_identifier_names

class ApiConstant {
  static const String baseUrl = "base_url";
  // static const String imageBaseUrl = 'imageBaseUrl';
  static const imageBaseUrl = "https://nusnas.com/";

  static const String googleApikey = "googleApikey";

  static const String public_stripe_key =
      'pk_test_PDKm8iAPqIq3mLuhQpm0vwAF00DvLrxre7';

  static const String secret_stripe_key =
      'sk_test_QBKHRBdegd6aqvyULJJMYklh00mMGXBsqG';
}
