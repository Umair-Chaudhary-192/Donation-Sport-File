class AppConstants {
  static const string = '';
}
