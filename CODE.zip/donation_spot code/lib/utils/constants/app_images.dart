class AppImages {

  // static const logo = 'assets/images/logo.svg';
  static const logoPng = 'assets/images/png/logo.png';
  static const imagePlaceHolder = 'assets/images/logo.png';

  static const arrowBack = 'assets/images/svg/arrow_back.svg';
  static const menuIcon = 'assets/images/svg/menuIcon.svg';
  static const cautionIcon = 'assets/images/svg/cutionIcon.svg';
  static const clockIcon = 'assets/images/svg/clock_icon.svg';
  static const locationPinIcon = 'assets/images/svg/location_pin_icon.svg';
  static const calenderIcon = 'assets/images/svg/calenderIcon.svg';
  static const dollarIcon = 'assets/images/svg/dollarIcon.svg';
}
