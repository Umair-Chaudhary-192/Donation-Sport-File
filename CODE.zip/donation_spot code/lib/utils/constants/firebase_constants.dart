//
// import 'package:firebase_auth/firebase_auth.dart';
//
// final FirebaseAuth auth = FirebaseAuth.instance;
// // final FacebookAuth fbAuth = FacebookAuth.instance;
// String postVideoFolderName='PostVideos';
// String postImagesFolderName='PostImages';
// String postThumbNailFolderName='PostThumbNails';
//
