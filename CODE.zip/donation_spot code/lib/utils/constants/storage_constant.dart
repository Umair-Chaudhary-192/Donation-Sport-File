

class StorageConstants {

  static String appColor = 'appColor';
  static String userToken = "userToken";
  static const loggedInData = 'loggedInData';
  static const eventId = 'eventId';
  static const profileImageUrl = 'profileImageUrl';
  static const langCountry = 'langCountry';
  static const langCode = 'langCode';

}
