import '../../app_modules/authentication/models/user.dart';

class UserData {
  UserModel? userData;


  UserData._privateConstructor();
  static UserData get instance => _instance;
  static final UserData _instance = UserData._privateConstructor();
  factory UserData() {
    return _instance;
  }
}